create definer = root@localhost trigger add_user_id_in_reservation
    before insert
    on reservation
    for each row
begin
            if new.user_id is null then
                set new.user_id = (select id from user where email = new.email);
            end if;
        end;

